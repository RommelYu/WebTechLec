Setting up the website

kuya index.html yung main page, thanks!